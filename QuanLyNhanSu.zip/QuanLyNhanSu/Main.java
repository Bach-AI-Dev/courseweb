import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Ngoại lệ riêng
class DuLieuKhongHopLeException extends Exception {
    public DuLieuKhongHopLeException(String message) {
        super(message);
    }
}

// Kiểm tra dữ liệu nhập
class KiemTra {
    public static String vanBan(String giaTri, String tenTruong) throws DuLieuKhongHopLeException {
        String s = giaTri == null ? "" : giaTri.trim();
        if (s.isEmpty())
            throw new DuLieuKhongHopLeException(tenTruong + " không được để trống!");
        if (s.contains(";"))
            throw new DuLieuKhongHopLeException(tenTruong + " không được chứa dấu ';'!");
        return s;
    }

    public static String hoTen(String giaTri) throws DuLieuKhongHopLeException {
        String s = vanBan(giaTri, "Họ tên");
        if (!s.matches("[\\p{L}\\p{M} .'\\-]+"))
            throw new DuLieuKhongHopLeException("Họ tên chỉ được chứa chữ cái và khoảng trắng!");
        return s;
    }

    public static String soDienThoai(String giaTri) throws DuLieuKhongHopLeException {
        String s = vanBan(giaTri, "Số điện thoại");
        if (!s.matches("0\\d{9}"))
            throw new DuLieuKhongHopLeException(
                    "Số điện thoại sai định dạng (gồm 10 chữ số, bắt đầu bằng số 0)!");
        return s;
    }

    public static double heSoCongViec(String giaTri) throws DuLieuKhongHopLeException {
        String s = vanBan(giaTri, "Hệ số công việc");
        if (s.startsWith("-"))
            throw new DuLieuKhongHopLeException("Hệ số công việc không được là số âm!");
        if (!s.matches("\\d+([.,]\\d+)?"))
            throw new DuLieuKhongHopLeException("Hệ số công việc phải là một số thực hợp lệ!");
        double hs = Double.parseDouble(s.replace(',', '.'));
        if (hs < 1 || hs > 20)
            throw new DuLieuKhongHopLeException("Hệ số công việc phải nằm trong khoảng từ 1 đến 20!");
        return hs;
    }

    public static int soNgay(String giaTri) throws DuLieuKhongHopLeException {
        String s = vanBan(giaTri, "Số ngày làm việc");
        if (s.startsWith("-"))
            throw new DuLieuKhongHopLeException("Số ngày làm việc không được là số âm!");
        if (!s.matches("\\d+"))
            throw new DuLieuKhongHopLeException("Số ngày làm việc phải là số nguyên!");
        int n;
        try {
            n = Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            throw new DuLieuKhongHopLeException("Số ngày làm việc quá lớn!");
        }
        if (n < 1 || n > 31)
            throw new DuLieuKhongHopLeException("Số ngày làm việc phải từ 1 đến 31!");
        return n;
    }
}

// Class Nhân viên

class NhanVien {
    private final int ma;
    private final String hoTen, diaChi, sdt;
    private final int bacLuong;

    public NhanVien(int ma, String hoTen, String diaChi, String sdt, int bacLuong) {
        this.ma = ma;
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.sdt = sdt;
        this.bacLuong = bacLuong;
    }

    public int getMa() {
        return ma;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public String getSdt() {
        return sdt;
    }

    public int getBacLuong() {
        return bacLuong;
    }

    public Object[] toObject() {
        return new Object[] { ma, hoTen, diaChi, sdt, bacLuong };
    }

    public String toLine() {
        return ma + ";" + hoTen + ";" + diaChi + ";" + sdt + ";" + bacLuong;
    }

    public static NhanVien fromLine(String line) throws DuLieuKhongHopLeException {
        String[] p = line.split(";", -1);
        if (p.length != 5)
            throw new DuLieuKhongHopLeException("Dòng nhân viên không đủ 5 trường: " + line);
        try {
            return new NhanVien(Integer.parseInt(p[0].trim()), p[1].trim(), p[2].trim(),
                    p[3].trim(), Integer.parseInt(p[4].trim()));
        } catch (NumberFormatException ex) {
            throw new DuLieuKhongHopLeException("Sai định dạng số trong dòng nhân viên: " + line);
        }
    }

    @Override
    public String toString() {
        return ma + " - " + hoTen;
    }
}

// Class Phòng ban

class PhongBan {
    private final int ma;
    private final String ten, moTa;
    private final double heSo;

    public PhongBan(int ma, String ten, String moTa, double heSo) {
        this.ma = ma;
        this.ten = ten;
        this.moTa = moTa;
        this.heSo = heSo;
    }

    public int getMa() {
        return ma;
    }

    public String getTen() {
        return ten;
    }

    public String getMoTa() {
        return moTa;
    }

    public double getHeSo() {
        return heSo;
    }

    public Object[] toObject() {
        return new Object[] { ma, ten, moTa, heSo };
    }

    public String toLine() {
        return ma + ";" + ten + ";" + moTa + ";" + heSo;
    }

    public static PhongBan fromLine(String line) throws DuLieuKhongHopLeException {
        String[] p = line.split(";", -1);
        if (p.length != 4)
            throw new DuLieuKhongHopLeException("Dòng phòng ban không đủ 4 trường: " + line);
        try {
            return new PhongBan(Integer.parseInt(p[0].trim()), p[1].trim(), p[2].trim(),
                    Double.parseDouble(p[3].trim()));
        } catch (NumberFormatException ex) {
            throw new DuLieuKhongHopLeException("Sai định dạng số trong dòng phòng ban: " + line);
        }
    }

    @Override
    public String toString() {
        return ma + " - " + ten;
    }
}

// Class Chấm công

class ChamCong {
    private final NhanVien nv;
    private final PhongBan pb;
    private final int soNgay;

    public ChamCong(NhanVien nv, PhongBan pb, int soNgay) {
        this.nv = nv;
        this.pb = pb;
        this.soNgay = soNgay;
    }

    public NhanVien getNv() {
        return nv;
    }

    public PhongBan getPb() {
        return pb;
    }

    public int getSoNgay() {
        return soNgay;
    }

    // Thu nhập = 1.450.000 * (2 + Bậc lương/3) * Hệ số công việc * (số ngày làm việc/22)

    public double tinhThuNhap() {
        return 1450000.0 * (2.0 + nv.getBacLuong() / 3.0) * pb.getHeSo() * (soNgay / 22.0);
    }

    public Object[] toObject() {
        return new Object[] { nv.getMa(), nv.getHoTen(), pb.getMa(), pb.getTen(), soNgay };
    }

    public Object[] toObjectThuNhap() {
        return new Object[] {
                nv.getMa(), nv.getHoTen(), pb.getTen(),
                nv.getBacLuong(), pb.getHeSo(), soNgay,
                String.format(Locale.forLanguageTag("vi-VN"), "%,.0f VNĐ", tinhThuNhap())
        };
    }

    // Một dòng trong QLNS.TXT: maNV;maPB;soNgay
    public String toLine() {
        return nv.getMa() + ";" + pb.getMa() + ";" + soNgay;
    }

    public static ChamCong fromLine(String line, List<NhanVien> dsNV, List<PhongBan> dsPB)
            throws DuLieuKhongHopLeException {
        String[] p = line.split(";", -1);
        if (p.length != 3)
            throw new DuLieuKhongHopLeException("Dòng chấm công không đủ 3 trường: " + line);
        try {
            int maNV = Integer.parseInt(p[0].trim());
            int maPB = Integer.parseInt(p[1].trim());
            int soNgay = Integer.parseInt(p[2].trim());

            NhanVien nv = null;
            for (NhanVien x : dsNV)
                if (x.getMa() == maNV)
                    nv = x;
            PhongBan pb = null;
            for (PhongBan x : dsPB)
                if (x.getMa() == maPB)
                    pb = x;

            if (nv == null)
                throw new DuLieuKhongHopLeException("QLNS.TXT tham chiếu nhân viên mã " + maNV
                        + " không có trong NV.TXT");
            if (pb == null)
                throw new DuLieuKhongHopLeException("QLNS.TXT tham chiếu phòng ban mã " + maPB
                        + " không có trong PB.TXT");
            return new ChamCong(nv, pb, soNgay);
        } catch (NumberFormatException ex) {
            throw new DuLieuKhongHopLeException("Sai định dạng số trong dòng chấm công: " + line);
        }
    }
}
// Đọc ghi file

class IOFile {
    private static List<String> docDong(String file) throws IOException {
        List<String> ketQua = new ArrayList<>();
        Path p = Paths.get(file);
        if (!Files.exists(p))
            return ketQua; 
        boolean dongDau = true;
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            if (dongDau) {
                line = line.replace("\uFEFF", "");
                dongDau = false;
            }
            if (!line.trim().isEmpty())
                ketQua.add(line.trim());
        }
        return ketQua;
    }

    private static void ghiDong(String file, List<String> dong) throws IOException {
        Files.write(Paths.get(file), dong, StandardCharsets.UTF_8);
    }

    public static List<NhanVien> docNV(String file) throws IOException, DuLieuKhongHopLeException {
        List<NhanVien> ds = new ArrayList<>();
        for (String line : docDong(file))
            ds.add(NhanVien.fromLine(line));
        return ds;
    }

    public static void ghiNV(String file, List<NhanVien> ds) throws IOException {
        List<String> dong = new ArrayList<>();
        for (NhanVien nv : ds)
            dong.add(nv.toLine());
        ghiDong(file, dong);
    }

    public static List<PhongBan> docPB(String file) throws IOException, DuLieuKhongHopLeException {
        List<PhongBan> ds = new ArrayList<>();
        for (String line : docDong(file))
            ds.add(PhongBan.fromLine(line));
        return ds;
    }

    public static void ghiPB(String file, List<PhongBan> ds) throws IOException {
        List<String> dong = new ArrayList<>();
        for (PhongBan pb : ds)
            dong.add(pb.toLine());
        ghiDong(file, dong);
    }

    public static List<ChamCong> docCC(String file, List<NhanVien> dsNV, List<PhongBan> dsPB)
            throws IOException, DuLieuKhongHopLeException {
        List<ChamCong> ds = new ArrayList<>();
        for (String line : docDong(file))
            ds.add(ChamCong.fromLine(line, dsNV, dsPB));
        return ds;
    }

    public static void ghiCC(String file, List<ChamCong> ds) throws IOException {
        List<String> dong = new ArrayList<>();
        for (ChamCong cc : ds)
            dong.add(cc.toLine());
        ghiDong(file, dong);
    }
}

// Giao diện chính
public class Main extends JFrame {
    private final List<NhanVien> listNV;
    private final List<PhongBan> listPB;
    private final List<ChamCong> listCC;

    private final DefaultTableModel modelNV, modelPB, modelCC, modelSort, modelThuNhap;
    private final JComboBox<NhanVien> cbNV;
    private final JComboBox<PhongBan> cbPB;

    private static final String FILE_NV = "NV.TXT";
    private static final String FILE_PB = "PB.TXT";
    private static final String FILE_CC = "QLNS.TXT";

    public Main() throws IOException, DuLieuKhongHopLeException {
        setTitle("QUẢN LÝ NHÂN SỰ - MSV:B24DCCN385");
        setSize(950, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        listNV = IOFile.docNV(FILE_NV);
        listPB = IOFile.docPB(FILE_PB);
        listCC = IOFile.docCC(FILE_CC, listNV, listPB);

        modelNV = taoModel("Mã NV", "Họ Tên", "Địa Chỉ", "Số ĐT", "Bậc Lương");
        modelPB = taoModel("Mã Phòng", "Tên Phòng", "Mô Tả", "Hệ Số CV");
        modelCC = taoModel("Mã NV", "Họ Tên NV", "Mã Phòng", "Tên Phòng", "Số Ngày Làm");
        modelSort = taoModel("Mã NV", "Họ Tên NV", "Mã Phòng", "Tên Phòng", "Số Ngày Làm");
        modelThuNhap = taoModel("Mã NV", "Họ Tên NV", "Phòng Ban", "Bậc Lương", "Hệ Số CV", "Số Ngày",
                "Thu Nhập Tháng");
        cbNV = new JComboBox<>();
        cbPB = new JComboBox<>();

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel pNV = new JPanel(new BorderLayout(10, 10));
        pNV.add(new JScrollPane(new JTable(modelNV)), BorderLayout.CENTER);

        JPanel formNV = new JPanel(new GridLayout(5, 2, 5, 5));
        formNV.setBorder(BorderFactory.createTitledBorder("Nhập thông tin Nhân Viên mới"));
        JTextField txtTenNV = new JTextField();
        JTextField txtDiaChi = new JTextField();
        JTextField txtSdt = new JTextField();
        JComboBox<Integer> cbBacLuong = new JComboBox<>(new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 });
        JButton btnThemNV = new JButton("Thêm Nhân Viên");

        formNV.add(new JLabel("  Họ tên:"));
        formNV.add(txtTenNV);
        formNV.add(new JLabel("  Địa chỉ:"));
        formNV.add(txtDiaChi);
        formNV.add(new JLabel("  Số điện thoại:"));
        formNV.add(txtSdt);
        formNV.add(new JLabel("  Bậc lương (1 - 9):"));
        formNV.add(cbBacLuong);
        formNV.add(new JLabel(""));
        formNV.add(btnThemNV);
        pNV.add(formNV, BorderLayout.SOUTH);

        btnThemNV.addActionListener(e -> {
            try {
                String ten = KiemTra.hoTen(txtTenNV.getText());
                String dc = KiemTra.vanBan(txtDiaChi.getText(), "Địa chỉ");
                String sdt = KiemTra.soDienThoai(txtSdt.getText());
                int bac = (Integer) cbBacLuong.getSelectedItem();

                int ma = Math.max(1000, listNV.stream().mapToInt(NhanVien::getMa).max().orElse(0) + 1);
                if (ma > 9999)
                    throw new DuLieuKhongHopLeException("Đã đạt số lượng nhân viên tối đa (mã 4 chữ số)!");

                NhanVien nv = new NhanVien(ma, ten, dc, sdt, bac);
                listNV.add(nv);
                try {
                    IOFile.ghiNV(FILE_NV, listNV);
                } catch (IOException ioEx) {
                    listNV.remove(nv);
                    throw ioEx;
                }
                modelNV.addRow(nv.toObject());
                capNhatComboBox();

                txtTenNV.setText("");
                txtDiaChi.setText("");
                txtSdt.setText("");
                JOptionPane.showMessageDialog(this, "Đã thêm Nhân viên và lưu vào " + FILE_NV + "!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi Nhập Liệu", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel pPB = new JPanel(new BorderLayout(10, 10));
        pPB.add(new JScrollPane(new JTable(modelPB)), BorderLayout.CENTER);

        JPanel formPB = new JPanel(new GridLayout(4, 2, 5, 5));
        formPB.setBorder(BorderFactory.createTitledBorder("Nhập thông tin Phòng Ban mới"));
        JTextField txtTenPB = new JTextField();
        JTextField txtMoTa = new JTextField();
        JTextField txtHeSo = new JTextField();
        JButton btnThemPB = new JButton("Thêm Phòng Ban");

        formPB.add(new JLabel("  Tên phòng:"));
        formPB.add(txtTenPB);
        formPB.add(new JLabel("  Mô tả:"));
        formPB.add(txtMoTa);
        formPB.add(new JLabel("  Hệ số công việc (1.0 - 20.0):"));
        formPB.add(txtHeSo);
        formPB.add(new JLabel(""));
        formPB.add(btnThemPB);
        pPB.add(formPB, BorderLayout.SOUTH);

        btnThemPB.addActionListener(e -> {
            try {
                String ten = KiemTra.vanBan(txtTenPB.getText(), "Tên phòng");
                String mt = KiemTra.vanBan(txtMoTa.getText(), "Mô tả");
                double hs = KiemTra.heSoCongViec(txtHeSo.getText());

                int ma = Math.max(100, listPB.stream().mapToInt(PhongBan::getMa).max().orElse(0) + 1);
                if (ma > 999)
                    throw new DuLieuKhongHopLeException("Đã đạt số lượng phòng ban tối đa (mã 3 chữ số)!");

                PhongBan pb = new PhongBan(ma, ten, mt, hs);
                listPB.add(pb);
                try {
                    IOFile.ghiPB(FILE_PB, listPB);
                } catch (IOException ioEx) {
                    listPB.remove(pb);
                    throw ioEx;
                }
                modelPB.addRow(pb.toObject());
                capNhatComboBox();

                txtTenPB.setText("");
                txtMoTa.setText("");
                txtHeSo.setText("");
                JOptionPane.showMessageDialog(this, "Đã thêm Phòng ban và lưu vào " + FILE_PB + "!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi Nhập Liệu", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel pCC = new JPanel(new BorderLayout(10, 10));
        pCC.add(new JScrollPane(new JTable(modelCC)), BorderLayout.CENTER);

        JPanel formCC = new JPanel(new GridLayout(4, 2, 5, 5));
        formCC.setBorder(BorderFactory.createTitledBorder("Lập Bảng Danh Sách Chấm Công"));
        JTextField txtSoNgay = new JTextField();
        JButton btnThemCC = new JButton("Chấm Công & Lưu");

        formCC.add(new JLabel("  Chọn Nhân viên:"));
        formCC.add(cbNV);
        formCC.add(new JLabel("  Chọn Phòng ban:"));
        formCC.add(cbPB);
        formCC.add(new JLabel("  Số ngày làm việc (1 - 31):"));
        formCC.add(txtSoNgay);
        formCC.add(new JLabel(""));
        formCC.add(btnThemCC);
        pCC.add(formCC, BorderLayout.SOUTH);

        btnThemCC.addActionListener(e -> {
            try {
                NhanVien nv = (NhanVien) cbNV.getSelectedItem();
                PhongBan pb = (PhongBan) cbPB.getSelectedItem();
                if (nv == null || pb == null)
                    throw new DuLieuKhongHopLeException("Vui lòng nhập dữ liệu Nhân viên và Phòng ban trước!");

                int soNgay = KiemTra.soNgay(txtSoNgay.getText());

                for (ChamCong c : listCC) {
                    if (c.getNv().getMa() == nv.getMa()) {
                        if (c.getPb().getMa() == pb.getMa())
                            throw new DuLieuKhongHopLeException("Nhân viên '" + nv.getHoTen()
                                    + "' đã được chấm công ở phòng '" + pb.getTen() + "' rồi!");
                        throw new DuLieuKhongHopLeException("Nhân viên '" + nv.getHoTen()
                                + "' đã được phân công ở phòng '" + c.getPb().getTen()
                                + "'!\n(Một nhân viên không thể làm ở 2 phòng ban khác nhau).");
                    }
                }

                ChamCong cc = new ChamCong(nv, pb, soNgay);
                listCC.add(cc);
                try {
                    IOFile.ghiCC(FILE_CC, listCC);
                } catch (IOException ioEx) {
                    listCC.remove(cc);
                    throw ioEx;
                }
                modelCC.addRow(cc.toObject());
                capNhatBangSortVaThuNhap();

                txtSoNgay.setText("");
                JOptionPane.showMessageDialog(this, "Đã lưu vào " + FILE_CC + "!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi Chấm Công", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel pSort = new JPanel(new BorderLayout(10, 10));
        pSort.add(new JScrollPane(new JTable(modelSort)), BorderLayout.CENTER);

        JPanel topSort = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        topSort.add(new JLabel("Chọn tiêu chí sắp xếp:"));
        JComboBox<String> cbSort = new JComboBox<>(new String[] {
                "Sắp xếp theo Tên Nhân Viên",
                "Sắp xếp theo Tên Phòng Ban"
        });
        JButton btnSort = new JButton("Thực Hiện Sắp Xếp");
        topSort.add(cbSort);
        topSort.add(btnSort);
        pSort.add(topSort, BorderLayout.NORTH);

        btnSort.addActionListener(e -> {
            List<ChamCong> copy = new ArrayList<>(listCC);
            if (cbSort.getSelectedIndex() == 0) {
                copy.sort((a, b) -> {
                    int cmp = boDau(layTenChinh(a.getNv().getHoTen()))
                            .compareToIgnoreCase(boDau(layTenChinh(b.getNv().getHoTen())));
                    if (cmp == 0)
                        cmp = boDau(a.getNv().getHoTen()).compareToIgnoreCase(boDau(b.getNv().getHoTen()));
                    if (cmp == 0)
                        cmp = Integer.compare(a.getNv().getMa(), b.getNv().getMa());
                    return cmp;
                });
            } else {
                copy.sort((a, b) -> {
                    int cmp = boDau(a.getPb().getTen()).compareToIgnoreCase(boDau(b.getPb().getTen()));
                    if (cmp == 0)
                        cmp = boDau(layTenChinh(a.getNv().getHoTen()))
                                .compareToIgnoreCase(boDau(layTenChinh(b.getNv().getHoTen())));
                    if (cmp == 0)
                        cmp = boDau(a.getNv().getHoTen()).compareToIgnoreCase(boDau(b.getNv().getHoTen()));
                    return cmp;
                });
            }
            modelSort.setRowCount(0);
            for (ChamCong cc : copy)
                modelSort.addRow(cc.toObject());
        });

        JPanel pThuNhap = new JPanel(new BorderLayout(10, 10));
        pThuNhap.add(new JScrollPane(new JTable(modelThuNhap)), BorderLayout.CENTER);

        JButton btnTinh = new JButton("Lập Bảng Kê Chi Tiết Thu Nhập");
        btnTinh.addActionListener(e -> capNhatBangSortVaThuNhap());
        pThuNhap.add(btnTinh, BorderLayout.NORTH);

        tabbedPane.addTab("Quản lý Nhân Viên", pNV);
        tabbedPane.addTab("Quản lý Phòng Ban", pPB);
        tabbedPane.addTab("Bảng Chấm Công", pCC);
        tabbedPane.addTab("Sắp Xếp Phân Công", pSort);
        tabbedPane.addTab("Bảng Kê Thu Nhập", pThuNhap);

        add(tabbedPane);
        taiDuLieuLenBang();
    }
    
    private DefaultTableModel taoModel(String... cot) {
        return new DefaultTableModel(cot, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private String layTenChinh(String hoTen) {
        String[] s = hoTen.trim().split("\\s+");
        return s[s.length - 1];
    }

    private String boDau(String s) {
        String t = Normalizer.normalize(s, Normalizer.Form.NFD);
        return t.replaceAll("\\p{M}", "").replace('đ', 'd').replace('Đ', 'D');
    }

    private void taiDuLieuLenBang() {
        for (NhanVien nv : listNV)
            modelNV.addRow(nv.toObject());
        for (PhongBan pb : listPB)
            modelPB.addRow(pb.toObject());
        for (ChamCong cc : listCC)
            modelCC.addRow(cc.toObject());
        capNhatComboBox();
        capNhatBangSortVaThuNhap();
    }

    private void capNhatComboBox() {
        NhanVien nvChon = (NhanVien) cbNV.getSelectedItem();
        PhongBan pbChon = (PhongBan) cbPB.getSelectedItem();

        cbNV.removeAllItems();
        for (NhanVien nv : listNV)
            cbNV.addItem(nv);
        cbPB.removeAllItems();
        for (PhongBan pb : listPB)
            cbPB.addItem(pb);

        if (nvChon != null)
            for (NhanVien nv : listNV)
                if (nv.getMa() == nvChon.getMa())
                    cbNV.setSelectedItem(nv);
        if (pbChon != null)
            for (PhongBan pb : listPB)
                if (pb.getMa() == pbChon.getMa())
                    cbPB.setSelectedItem(pb);
    }

    private void capNhatBangSortVaThuNhap() {
        modelSort.setRowCount(0);
        modelThuNhap.setRowCount(0);
        for (ChamCong cc : listCC) {
            modelSort.addRow(cc.toObject());
            modelThuNhap.addRow(cc.toObjectThuNhap());
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }

        SwingUtilities.invokeLater(() -> {
            try {
                new Main().setVisible(true);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,
                        "Không đọc được dữ liệu từ file:\n" + ex.getMessage()
                                + "\n\nChương trình sẽ đóng để tránh ghi đè dữ liệu cũ.\n"
                                + "Hãy kiểm tra lại nội dung các file NV.TXT, PB.TXT, QLNS.TXT.",
                        "Lỗi đọc file", JOptionPane.ERROR_MESSAGE);
                System.exit(1);
            }
        });
    }
}